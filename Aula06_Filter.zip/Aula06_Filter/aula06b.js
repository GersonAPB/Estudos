const caixaAlunos = document.querySelector('#caixaAlunos');
const btn_a = [...document.querySelectorAll('.aluno')];
const a1_2 = document.querySelector('#a1_2');
const alunos = ['Aramil', 'Akta', 'Erehorn', 'Krusk', 'Fawn', 'Vincent'];
const btnAlunoSelecionado = document.getElementById('btnAlunoSelecionado');
const btnExcluirAluno = document.getElementById('btnRemoverAluno');
const btnAdicionarNovoAluno = document.getElementById('btnAdicionarNovoAluno');

var ids = alunos.length;

alunos.map((el, chave) => {
    const novoElemento = document.createElement('div');
    novoElemento.setAttribute('id', 'a' + chave);
    novoElemento.setAttribute('class', 'aluno a1');
    novoElemento.innerHTML = el;

    const comandos = document.createElement('div');
    comandos.setAttribute('class', 'comandos');

    const rb = document.createElement('input');
    rb.setAttribute('type', 'radio');
    rb.setAttribute('name', 'rb_aluno');

    comandos.appendChild(rb);

    novoElemento.appendChild(comandos);

    caixaAlunos.appendChild(novoElemento);
})
/*
btnAlunoSelecionado.addEventListener('click', (evt)=>{
    const tdsRadios = [...document.querySelectorAll('input[type=radio]')];
    let radioSelec = tdsRadios.filter((ele)=>{
        return ele.checked;
    })
    return radioSelec[0];
    const alunoSelect = (radioSelec.parentNode).parentNode.firstChild.textContent;
  
    alert(alunoSelect + ' vai morrer')
})
*/

const radioSelec = () => {
    const tdsRadios = [...document.querySelectorAll('input[type=radio]')];
    const radioSelec = tdsRadios.filter((ele) => {
        return ele.checked;
    })
    return radioSelec[0];
}

btnAlunoSelecionado.addEventListener('click', () => {
    const rs = radioSelec();
    if (rs != undefined) {
        const alunoSelect = rs.parentNode.parentNode.firstChild.textContent;
        alert(alunoSelect + ' vai morrer')
    }
})

btnExcluirAluno.addEventListener('click', () => {
    const rs = radioSelec();
    if (rs != undefined) {
        const alunoSelect = rs.parentNode.parentNode;
        alunoSelect.remove();
    }
})

btnAdicionarNovoAluno.addEventListener('click', ()=>{
    const nome = document.querySelector('#nomeAluno').value;
    const novoElemento = document.createElement('div');
    ids++
    novoElemento.setAttribute('id', 'a' + ids);
    novoElemento.setAttribute('class', 'aluno a1');
    novoElemento.innerHTML = nome;

    const comandos = document.createElement('div');
    comandos.setAttribute('class', 'comandos');

    const rb = document.createElement('input');
    rb.setAttribute('type', 'radio');
    rb.setAttribute('name', 'rb_aluno');

    comandos.appendChild(rb);

    novoElemento.appendChild(comandos);

    caixaAlunos.appendChild(novoElemento);
})