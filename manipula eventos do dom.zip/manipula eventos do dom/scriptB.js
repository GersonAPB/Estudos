const caixa1 = document.querySelector('#caixa1');
const btn_a1 = document.querySelector('.a1')
const alunos = [...document.querySelectorAll('.aluno')]

caixa1.addEventListener('click', ()=>{
    console.log('clicou');
})

btn_a1.addEventListener('click',(evt)=>{
    evt.stopPropagation();
})

alunos.map((el)=>{
    el.addEventListener('click', (evt)=>{
        evt.stopPropagation();
    })
})