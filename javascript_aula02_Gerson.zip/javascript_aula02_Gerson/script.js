function get(id) {
    return document.getElementById(id)
}

function mostraData() {
    get("data").innerHTML = Date();
    //document.getElementById("data").innerHTML = Date();
    
}

function mostraMensagem() {
    get("msg").innerHTML = "Estou aprendendo a programar em JavaScript";
    //document.getElementById("msg").innerHTML = "Estou aprendendo a programar em JavaScript";
    
}

function teste() {

    
}