function get(id) {
    return document.getElementById(id);
}

function pesquisa() {
    var pesquisa = get('pesquisa');
    pesquisa.style.display = 'block';
}

function fecha(elemt) {
    var elemento = get(elemt);
    if (elemento.style.display=='block') {
        elemento.style.display='none'
    }
}