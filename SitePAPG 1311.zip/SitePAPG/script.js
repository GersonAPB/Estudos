function get(id) {
    return document.getElementById(id);
}

function mostrainfo(id, modo) {
    var elemento = get(id);
    elemento.style.display = modo;
}

function teste(elem,id) {
    var elemento = get(elem);
    switch (elem) {
        case 'RA':
            get('RG').checked = false;
            mostrainfo('aritmetica', `${elemento.style.display == 'none' ? 'none' : 'block'}`)
            mostrainfo('geometrica', `${elemento.style.display == 'block' ? 'block' : 'none'}`)
            break;
        case 'RG':
            get('RA').checked = false;
            mostrainfo('geometrica', `${elemento.style.display == 'none' ? 'none' : 'block'}`)
            mostrainfo('aritmetica', `${elemento.style.display == 'block' ? 'block' : 'none'}`)
            break;
        case 'GAME':
            mostrainfo(id ,`${elemento.style.display == 'none' ? 'none' : 'block'}`)
            
            break;
        default:
            break;
    }


}

