function get(id) {
    return document.getElementById(id);
}

function testa(id1,id2,txid,op) {
    var num1 = get(id1).value;
    var num2 = get(id2).value;
    var texto = get(txid);
    var resultado;
    if(op =='=='){
       resultado = (num1 == num2);
    }else if(op =='!=') {
        resultado = (num1!=num2);
    }else if(op =='>') {
        resultado = (num1 > num2);
    }else if(op =='>=') {
        resultado = (num1 >= num2);
    }else if(op =='<') {
        resultado = (num1 < num2);
    }else{
        resultado = (num1 <= num2);
    }
    if (resultado==true) {
        texto.style.color = 'green';
        texto.innerHTML = 'Verdadeiro';
    }else{
        texto.style.color = 'red';
        texto.innerHTML = 'Falso';
    }

}