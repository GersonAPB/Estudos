var nome = "";
var idade;
function guarda(){
    nome = document.getElementById("nome").value;
    var mostra = document.getElementById("amais");
    mostra.style.display = 'inline';
}

function envia(){
    idade = document.getElementById("idade").value;
    var para = document.getElementById("Aparece");
    console.log(nome,idade)
    para.innerHTML = "Seu nome é " + nome +" e você tem "+idade+" anos."
}