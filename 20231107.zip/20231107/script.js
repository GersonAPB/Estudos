function get(id) {
    return document.getElementById(id);
}

function texto(id, texto) {
    get(id).innerHTML = texto;
}


function progressao() {
    var termo = parseInt(get('termo').value);
    var razao = parseInt(get('razao').value);
    var ultimo = parseInt(get('ultimo').value)-1;
    var text = `${termo}`;
    var numero = termo;
    for (let index = 0; index < ultimo; index++) {
        numero += razao;
        text += `${text =='' ? '' : ', '} ${numero}${index==ultimo-1 ? '.' : ''}`;
    }
    texto('txt1',text);
}

function fibonacci() {
    var sequencia = parseInt(get('sequecia').value);
    var num1 = 0;
    var num2 = 1;
    var num;
    var text = '';
    for (let index = 0; index < sequencia; index++) {
        
        text += `${text =='' ? '' : ', '} ${num2}`;
        num = num2 + num1;
        num1 = num2
        num2 = num
    }
    texto('txt2', text);
}