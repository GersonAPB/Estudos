const bloqueios = [11,12,13,14,15,21,25,31,35,41,45,51,52,53,54,55];

const coordCalcMap = new Map([
  ["cima", 1],["baixo", -1],["direita", 10],
  ["esquerda", -10],["DSD", 11],["DIE", -11],
  ["DSE", -9],["DID", 9]]);
  
var coordenada = 33
var palavra = [];
var numero = [];
var letra = [];

function move(key) {
	coordenada += coordCalcMap.get(key);	
}

function get(id) {
	return document.getElementById(id);
}

function updateCoordenada() {
	coordenada = parseInt(get("NovaCoordenada").value);
}

function RevelaPalavra() {
	get("imprime").innerHTML = palavra;
	palavra = [];
}

// Cria um array com as coordenadas
function setNumeros() {
	var index = 0;
	for (let j = 5; j > 0; j--) {
		for (let i = 1; i < 6; i++) {
			numero[index++] = i.toString() + j.toString();
		
		}
	}
}
// Usa ASCII para criar o array de letras maiúsculas
function setLetras() {
  let index = 0;
  for (let i = 65; i < 90; i++) {
    letra[index++] = String.fromCharCode(i);
  }
}

function localizacao() {	
	var posicao = numero.indexOf(coordenada.toString());
	palavra.push(letra[posicao]);
}

function renova() {
	const botoes = document.querySelectorAll(".direcoes");
	for (const botao of botoes) {
  		botao.disabled = false;
	}
}

function verificacaodebloqueio() {
	renova()
	if (bloqueios.includes(coordenada)) {
		bloqueio();
	}
}
function disableThese(btn) {
	for(let i = 0; i < btn.length; i++) {
		get(btn[i]).disabled = true;
	}
}
function bloqueio() {
	if ([25,35,45].includes(coordenada)) {
		disableThese(["DSEsquerda","C","DSDireita"]);
	} else if([21,31,41].includes(coordenada)) {
		disableThese(["DIDireita","B","DIEsquerda"]);
	} else if([54,53,52].includes(coordenada)) {
		disableThese(["DSDireita","D","DIDireita"]);
	} else if([14,13,12].includes(coordenada)) {
		disableThese(["DSEsquerda","E","DIEsquerda"]);
	} else if (coordenada == 15){
		disableThese(["DSEsquerda","C","DSDireita","E","DIEsquerda"]);
	} else if (coordenada == 55){
		disableThese(["DSEsquerda","C","DSDireita","D","DIDireita"]);
	} else if (coordenada == 11){
		disableThese(["DSEsquerda","E","DIEsquerda","B","DIDireita"]);
	} else if (coordenada == 51){
		disableThese(["DSDireita","D","DIDireita","B","DIEsquerda"]);
	}
}